// PPSSPP Overcast Skies
// By Stochastic Stoat

#ifdef GL_ES
precision mediump float;
precision mediump int;
#endif

uniform sampler2D sampler0;
uniform vec4 u_setting;
varying vec2 v_texcoord0;

/*
  Overcast Shader
  Setting 1: Overcast Desaturation (0 = off, 1 = full targeted desaturation)
  Setting 2: Overcast Gate (smaller = narrower color match, larger = wider)
  Setting 3: Temperature (0 = neutral, 1 = strongest cool shift)
  Setting 4: Tint (-1 = green, 0 = neutral, +1 = magenta)

  Target colors:
  #91ABE5, #C29290, #575E40, #4A4C16
*/

float colorMatch(vec3 color, vec3 target, float radius, float softness) {
    float distanceToTarget = distance(color, target);
    return 1.0 - smoothstep(radius - softness, radius + softness, distanceToTarget);
}

void main() {
    vec4 source = texture2D(sampler0, v_texcoord0);
    vec3 color = source.rgb;

    float overcastDesat = clamp(u_setting.x, 0.0, 1.0);
    float gate = clamp(u_setting.y, 0.0, 1.0);
    float temperature = clamp(u_setting.z, 0.0, 1.0);
    float tint = clamp(u_setting.w, -1.0, 1.0);

    // Gate controls the RGB distance around each sampled palette color.
    // A small nonzero minimum keeps the gate useful at its lowest setting.
    float radius = mix(0.015, 0.45, gate);
    float softness = max(0.008, radius * 0.22);

    vec3 target1 = vec3(0.5686, 0.6706, 0.8980); // #91ABE5
    vec3 target2 = vec3(0.7608, 0.5725, 0.5647); // #C29290
    vec3 target3 = vec3(0.3412, 0.3686, 0.2510); // #575E40
    vec3 target4 = vec3(0.2902, 0.2980, 0.0863); // #4A4C16

    float match = max(
        max(colorMatch(color, target1, radius, softness),
            colorMatch(color, target2, radius, softness)),
        max(colorMatch(color, target3, radius, softness),
            colorMatch(color, target4, radius, softness))
    );

    // Desaturate only pixels close to one of the four sampled colors.
    float luma = dot(color, vec3(0.299, 0.587, 0.114));
    color = mix(color, vec3(luma), match * overcastDesat);

    // Cool-only color temperature shift.
    color.r *= (1.0 - 0.22 * temperature);
    color.g *= (1.0 - 0.04 * temperature);
    color.b *= (1.0 + 0.24 * temperature);

    // Tint: negative adds green; positive adds magenta.
    color.r += max(tint, 0.0) * 0.10;
    color.b += max(tint, 0.0) * 0.10;
    color.g += max(-tint, 0.0) * 0.10;

    color = clamp(color, 0.0, 1.0);
    gl_FragColor = vec4(color, source.a);
}
